# Kxko Brief V2

Native Android app (Kotlin, Jetpack Compose). Package `com.kxko.briefv2`, runs next to the old app.

## Screens
- **Home**: weekly distance ring (goal 100 km), 7-day chart, last ride, study status.
- **Ride**: GPS recording as a foreground service (keeps tracking with the screen off). Pause/resume, live speed, distance, average speed, climb and route.
- **Study**: flashcard deck with a Leitner system (Got it / Again), animated flip.
- **History**: all rides with route thumbnails, expandable details, delete.

## Build
Open in Android Studio (Ladybug or newer), let Gradle sync, run on a device with GPS. Requires Android 8.0+.

## Not yet ported from V1
- Supabase login and exam question sync (V2 uses the built-in sample deck).
- Watch workout detection and automatic ride end at known locations.
- Firebase push and in-app updater.
