package com.kxko.briefv2.ride

import android.content.Context
import android.location.Location
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.*

data class LatLon(val lat: Double, val lon: Double, val alt: Double?)

/** A finished ride, stored on the device. */
data class Ride(
    val id: Long,
    val startMs: Long,
    val durationSec: Long,
    val distanceM: Double,
    val elevGainM: Double,
    val maxSpeedMps: Double,
    val points: List<LatLon>
) {
    val avgSpeedMps: Double get() = if (durationSec > 0) distanceM / durationSec else 0.0
    /** Very rough estimate (about 32 kcal per km). */
    val kcalEstimate: Int get() = (distanceM / 1000.0 * 32.0).roundToInt()

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("startMs", startMs)
        put("durationSec", durationSec)
        put("distanceM", distanceM)
        put("elevGainM", elevGainM)
        put("maxSpeedMps", maxSpeedMps)
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().put("la", p.lat).put("lo", p.lon).put("al", p.alt ?: JSONObject.NULL))
        }
        put("points", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): Ride {
            val arr = o.getJSONArray("points")
            val pts = (0 until arr.length()).map { i ->
                val p = arr.getJSONObject(i)
                LatLon(p.getDouble("la"), p.getDouble("lo"), if (p.isNull("al")) null else p.getDouble("al"))
            }
            return Ride(
                id = o.getLong("id"),
                startMs = o.getLong("startMs"),
                durationSec = o.getLong("durationSec"),
                distanceM = o.getDouble("distanceM"),
                elevGainM = o.getDouble("elevGainM"),
                maxSpeedMps = o.getDouble("maxSpeedMps"),
                points = pts
            )
        }
    }
}

/** Ride in progress, shown live on the Ride screen. */
data class LiveRide(
    val active: Boolean = false,
    val paused: Boolean = false,
    val startMs: Long = 0L,
    val elapsedSec: Long = 0L,
    val distanceM: Double = 0.0,
    val elevGainM: Double = 0.0,
    val speedMps: Double = 0.0,
    val maxSpeedMps: Double = 0.0,
    val points: List<LatLon> = emptyList()
)

/** In-memory tracker. The RideService feeds it location updates. */
object RideTracker {
    private val _state = MutableStateFlow(LiveRide())
    val state: StateFlow<LiveRide> = _state.asStateFlow()

    private const val MAX_ACCURACY_M = 25f
    private const val MIN_STEP_M = 2.0
    private const val MIN_CLIMB_M = 0.8 // ignores GPS altitude jitter

    fun begin(now: Long = System.currentTimeMillis()) {
        _state.value = LiveRide(active = true, startMs = now)
    }

    fun tick() {
        val s = _state.value
        if (s.active && !s.paused) _state.value = s.copy(elapsedSec = s.elapsedSec + 1)
    }

    fun togglePause() {
        val s = _state.value
        if (s.active) _state.value = s.copy(paused = !s.paused, speedMps = 0.0)
    }

    fun onLocation(loc: Location) {
        val s = _state.value
        if (!s.active || s.paused) return
        if (loc.hasAccuracy() && loc.accuracy > MAX_ACCURACY_M) return

        val p = LatLon(loc.latitude, loc.longitude, if (loc.hasAltitude()) loc.altitude else null)
        var dist = s.distanceM
        var climb = s.elevGainM
        val last = s.points.lastOrNull()
        if (last != null) {
            val step = haversine(last, p)
            if (step < MIN_STEP_M) return
            dist += step
            val a = last.alt
            val b = p.alt
            if (a != null && b != null && b - a > MIN_CLIMB_M) climb += b - a
        }
        val speed = if (loc.hasSpeed()) loc.speed.toDouble().coerceAtLeast(0.0) else 0.0
        _state.value = s.copy(
            points = s.points + p,
            distanceM = dist,
            elevGainM = climb,
            speedMps = speed,
            maxSpeedMps = max(s.maxSpeedMps, speed)
        )
    }

    /** Ends the ride and resets the live state. Returns null if nothing was recorded. */
    fun finish(): Ride? {
        val s = _state.value
        _state.value = LiveRide()
        if (!s.active || s.points.size < 2) return null
        return Ride(
            id = s.startMs,
            startMs = s.startMs,
            durationSec = s.elapsedSec,
            distanceM = s.distanceM,
            elevGainM = s.elevGainM,
            maxSpeedMps = s.maxSpeedMps,
            points = s.points
        )
    }

    fun haversine(a: LatLon, b: LatLon): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }
}

/** Saves finished rides as JSON in the app's private storage. */
object RideStore {
    private const val FILE = "rides_v2.json"

    fun load(ctx: Context): List<Ride> = try {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) emptyList() else {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { Ride.fromJson(arr.getJSONObject(it)) }
                .sortedByDescending { it.startMs }
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun save(ctx: Context, rides: List<Ride>) {
        val arr = JSONArray()
        rides.forEach { arr.put(it.toJson()) }
        File(ctx.filesDir, FILE).writeText(arr.toString())
    }

    fun append(ctx: Context, ride: Ride) = save(ctx, listOf(ride) + load(ctx))

    fun delete(ctx: Context, id: Long) = save(ctx, load(ctx).filterNot { it.id == id })
}
