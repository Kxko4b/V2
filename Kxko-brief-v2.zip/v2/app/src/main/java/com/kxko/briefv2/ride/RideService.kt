package com.kxko.briefv2.ride

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Foreground service: keeps GPS running while the screen is off. */
class RideService : Service() {

    private val lm by lazy { getSystemService(Context.LOCATION_SERVICE) as LocationManager }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ticker: Job? = null

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = RideTracker.onLocation(location)
        override fun onProviderDisabled(provider: String) = Unit
        override fun onProviderEnabled(provider: String) = Unit
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRide()
            ACTION_PAUSE -> RideTracker.togglePause()
            ACTION_STOP -> stopRide()
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startRide() {
        if (RideTracker.state.value.active) return
        startForegroundCompat(buildNotification("Ride in progress"))
        RideTracker.begin()
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2_000L, 3f, listener, mainLooper)
        } catch (_: SecurityException) {
            RideTracker.finish()
            stopSelf()
            return
        }
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                delay(1_000)
                RideTracker.tick()
                updateNotification()
            }
        }
    }

    private fun stopRide() {
        lm.removeUpdates(listener)
        ticker?.cancel()
        RideTracker.finish()?.let { RideStore.append(this, it) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        val s = RideTracker.state.value
        val km = "%.2f km".format(s.distanceM / 1000.0)
        val mins = s.elapsedSec / 60
        val status = if (s.paused) "Paused" else "Riding"
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification("$status · $km · $mins min"))
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Ride tracking", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Kxko Brief")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        lm.removeUpdates(listener)
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.kxko.briefv2.START"
        const val ACTION_PAUSE = "com.kxko.briefv2.PAUSE"
        const val ACTION_STOP = "com.kxko.briefv2.STOP"
        private const val CHANNEL_ID = "ride_tracking"
        private const val NOTIF_ID = 42

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, RideService::class.java).setAction(action)
            if (action == ACTION_START) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
