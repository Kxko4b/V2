package com.kxko.briefv2.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kxko.briefv2.ride.LatLon
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/** Rounded surface card with a subtle border. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (highlight) Palette.Ink2 else Palette.Ink1)
            .border(1.dp, if (highlight) Palette.Teal.copy(alpha = 0.4f) else Palette.Edge, shape)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(20.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = Palette.Teal,
        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold
    )
}

/** Number that counts smoothly to its new value. */
@Composable
fun AnimatedNumber(
    value: Double,
    format: (Double) -> String,
    style: TextStyle,
    color: Color = Palette.Text,
    modifier: Modifier = Modifier
) {
    val animated by animateFloatAsState(value.toFloat(), tween(700, easing = FastOutSlowInEasing), label = "num")
    Text(format(animated.toDouble()), style = style, color = color, modifier = modifier)
}

@Composable
fun AnimatedRing(
    fraction: Float,
    size: Dp,
    stroke: Dp,
    color: Color = Palette.Teal,
    modifier: Modifier = Modifier,
    center: @Composable () -> Unit = {}
) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(1000, easing = FastOutSlowInEasing), label = "ring")
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val px = stroke.toPx()
            val inset = px / 2f
            val arc = Size(this.size.width - px, this.size.height - px)
            drawArc(Palette.Edge, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(px))
            if (animated > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Palette.Teal, Palette.TealBright, Palette.Teal)),
                    startAngle = -90f,
                    sweepAngle = 360f * animated,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arc,
                    style = Stroke(px, cap = StrokeCap.Round)
                )
            }
        }
        center()
    }
}

/** Blinking red-free "recording" dot. */
@Composable
fun PulseDot(color: Color = Palette.Danger, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse-alpha"
    )
    Box(modifier.size(10.dp).alpha(a).clip(CircleShape).background(color))
}

/** Route drawn as a glowing polyline. Animates in once, then follows new points. */
@Composable
fun RouteCanvas(points: List<LatLon>, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val draw by animateFloatAsState(if (shown) 1f else 0f, tween(900, easing = FastOutSlowInEasing), label = "route")

    Canvas(modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Palette.Ink2)) {
        if (points.size < 2) return@Canvas
        val pad = 22.dp.toPx()
        val minLat = points.minOf { it.lat }
        val maxLat = points.maxOf { it.lat }
        val minLon = points.minOf { it.lon }
        val maxLon = points.maxOf { it.lon }
        val cosLat = cos(Math.toRadians((minLat + maxLat) / 2)).coerceAtLeast(0.2)
        val rangeX = max((maxLon - minLon) * cosLat, 1e-6)
        val rangeY = max(maxLat - minLat, 1e-6)
        val scale = min((size.width - 2 * pad) / rangeX, (size.height - 2 * pad) / rangeY).toFloat()
        val offX = (size.width - rangeX.toFloat() * scale) / 2f
        val offY = (size.height - rangeY.toFloat() * scale) / 2f

        fun project(p: LatLon) = Offset(
            offX + ((p.lon - minLon) * cosLat).toFloat() * scale,
            offY + ((maxLat - p.lat)).toFloat() * scale
        )

        val n = max(2, (points.size * draw).toInt())
        val path = Path()
        points.take(n).forEachIndexed { i, p ->
            val o = project(p)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(
            path,
            brush = Brush.linearGradient(listOf(Palette.Teal, Palette.TealBright)),
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawCircle(Palette.Success, 6.dp.toPx(), project(points.first()))
        if (draw >= 1f) drawCircle(Palette.Danger, 6.dp.toPx(), project(points.last()))
    }
}

/** Simple animated bar chart, one bar per label. */
@Composable
fun WeekBars(values: List<Float>, labels: List<String>, modifier: Modifier = Modifier) {
    val max = values.maxOrNull()?.takeIf { it > 0f } ?: 1f
    Row(modifier.fillMaxWidth().height(140.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        values.forEachIndexed { i, v ->
            val target = if (v > 0f) (v / max).coerceIn(0.06f, 1f) else 0.04f
            val h by animateFloatAsState(target, tween(800, easing = FastOutSlowInEasing), label = "bar")
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.fillMaxWidth().fillMaxHeight(h).clip(RoundedCornerShape(8.dp))
                            .background(
                                if (i == values.lastIndex) Brush.verticalGradient(listOf(Palette.TealBright, Palette.Teal))
                                else Brush.verticalGradient(listOf(Palette.Teal.copy(alpha = 0.55f), Palette.Teal.copy(alpha = 0.25f)))
                            )
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(labels.getOrElse(i) { "" }, color = Palette.TextDim, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Palette.Ink2)
            .padding(14.dp)
    ) {
        Text(label.uppercase(), color = Palette.TextDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(4.dp))
            Text(unit, color = Palette.TextSoft, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val scale by animateFloatAsState(if (enabled) 1f else 0.97f, tween(160), label = "btn")
    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .background(if (enabled) Palette.Teal else Palette.Ink3)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Palette.OnTeal else Palette.TextDim, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = Palette.TextSoft) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, Palette.Edge, RoundedCornerShape(18.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
