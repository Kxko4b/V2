package com.kxko.briefv2.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Palette {
    val Ink0 = Color(0xFF080B10)
    val Ink1 = Color(0xFF0F141B)
    val Ink2 = Color(0xFF161D26)
    val Ink3 = Color(0xFF1F2A36)
    val Edge = Color(0xFF26323F)
    val Teal = Color(0xFF2EC4B6)
    val TealBright = Color(0xFF5FE3D5)
    val TealSoft = Color(0x262EC4B6)
    val OnTeal = Color(0xFF03211E)
    val Text = Color(0xFFEEF3F7)
    val TextSoft = Color(0xFFA3B0BE)
    val TextDim = Color(0xFF67768A)
    val Success = Color(0xFF7BE0A4)
    val Warning = Color(0xFFFFB547)
    val Danger = Color(0xFFFF7A7A)
}

private val V2Typography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 56.sp, lineHeight = 60.sp, letterSpacing = (-1.5).sp),
    displayMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 40.sp, lineHeight = 44.sp, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.6.sp)
)

@Composable
fun BriefTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Teal,
            onPrimary = Palette.OnTeal,
            primaryContainer = Palette.TealSoft,
            onPrimaryContainer = Palette.TealBright,
            secondary = Palette.TealBright,
            background = Palette.Ink0,
            onBackground = Palette.Text,
            surface = Palette.Ink1,
            onSurface = Palette.Text,
            surfaceVariant = Palette.Ink2,
            onSurfaceVariant = Palette.TextSoft,
            outline = Palette.Edge,
            error = Palette.Danger
        ),
        typography = V2Typography,
        content = content
    )
}
