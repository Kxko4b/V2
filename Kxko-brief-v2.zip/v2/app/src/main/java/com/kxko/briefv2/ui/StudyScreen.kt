package com.kxko.briefv2.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kxko.briefv2.study.Card
import com.kxko.briefv2.study.StudyStore
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun StudyScreen(cards: List<Card>, boxes: Map<String, Int>, onGrade: (String, Boolean) -> Unit) {
    val total = cards.size.coerceAtLeast(1)
    val mastered = StudyStore.masteredCount(cards, boxes)
    val progress by animateFloatAsState(mastered / total.toFloat(), tween(700), label = "study-progress")
    val card = StudyStore.nextCard(cards, boxes)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Study", style = MaterialTheme.typography.headlineLarge)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row {
                Text("$mastered of $total mastered", color = Palette.TextSoft, fontSize = 13.sp)
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                color = Palette.Teal,
                trackColor = Palette.Ink3
            )
        }

        if (card == null) {
            GlassCard(highlight = true) {
                Text("All cards mastered", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Every card has reached the top box. New cards can be added to the deck later.", color = Palette.TextSoft)
            }
        } else {
            FlashCard(card = card, onGrade = { gotIt -> onGrade(card.id, gotIt) })
        }

        Text(
            "Got it moves a card up. Again sends it back to the start. Cards you miss come back sooner.",
            color = Palette.TextDim,
            fontSize = 12.sp
        )
    }
}

/** Card that flips with a 3D rotation when tapped. Front and back are shown one after another. */
@Composable
private fun FlashCard(card: Card, onGrade: (Boolean) -> Unit) {
    var flipped by remember(card.id) { mutableStateOf(false) }
    val rotation by animateFloatAsState(if (flipped) 180f else 0f, tween(500), label = "flip")
    val showBack = rotation > 90f

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(300.dp)
                .graphicsLayer {
                    rotationY = rotation
                    cameraDistance = 14f * density
                }
                .clip(RoundedCornerShape(28.dp))
                .background(if (showBack) Palette.Ink3 else Palette.Ink1)
                .border(1.dp, if (showBack) Palette.Teal.copy(alpha = 0.5f) else Palette.Edge, RoundedCornerShape(28.dp))
                .clickable { flipped = !flipped }
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { rotationY = if (showBack) 180f else 0f }
            ) {
                Text(
                    if (showBack) "ANSWER" else "QUESTION",
                    color = Palette.Teal,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    if (showBack) card.back else card.front,
                    color = Palette.Text,
                    fontSize = if (showBack) 20.sp else 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 30.sp
                )
                if (!flipped) {
                    Spacer(Modifier.height(20.dp))
                    Text("Tap to reveal", color = Palette.TextDim, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        if (!flipped) {
            PrimaryButton("Show answer", onClick = { flipped = true }, modifier = Modifier.fillMaxWidth())
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                GhostButton("Again", onClick = { onGrade(false) }, modifier = Modifier.weight(1f), color = Palette.Danger)
                PrimaryButton("Got it", onClick = { onGrade(true) }, modifier = Modifier.weight(1f))
            }
        }
    }
}
