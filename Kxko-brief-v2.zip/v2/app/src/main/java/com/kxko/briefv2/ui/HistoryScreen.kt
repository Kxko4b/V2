package com.kxko.briefv2.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kxko.briefv2.fmtDate
import com.kxko.briefv2.fmtDuration
import com.kxko.briefv2.fmtKm
import com.kxko.briefv2.fmtKmh
import com.kxko.briefv2.ride.Ride

@Composable
fun HistoryScreen(rides: List<Ride>, onDelete: (Long) -> Unit) {
    val totalM = rides.sumOf { it.distanceM }
    val totalSec = rides.sumOf { it.durationSec }
    val totalClimb = rides.sumOf { it.elevGainM }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("History", style = MaterialTheme.typography.headlineLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Rides", "${rides.size}", "", Modifier.weight(1f))
                    StatTile("Distance", fmtKm(totalM), "km", Modifier.weight(1f))
                    StatTile("Climb", "%.0f".format(totalClimb), "m", Modifier.weight(1f))
                }
                Text(fmtDuration(totalSec) + " in the saddle", color = Palette.TextSoft, fontSize = 13.sp)
            }
        }

        if (rides.isEmpty()) {
            item {
                GlassCard {
                    Text("No rides yet", style = MaterialTheme.typography.titleMedium)
                    Text("Finished rides appear here with their route.", color = Palette.TextSoft)
                }
            }
        }

        items(rides, key = { it.id }) { ride ->
            RideItem(ride = ride, onDelete = { onDelete(ride.id) })
        }
    }
}

@Composable
private fun RideItem(ride: Ride, onDelete: () -> Unit) {
    var open by remember(ride.id) { mutableStateOf(false) }
    GlassCard(onClick = { open = !open }, highlight = open) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(fmtDate(ride.startMs), color = Palette.TextSoft, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "${fmtKm(ride.distanceM)} km",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${fmtDuration(ride.durationSec)} · avg ${fmtKmh(ride.avgSpeedMps)} km/h",
                    color = Palette.TextSoft,
                    fontSize = 13.sp
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        RouteCanvas(ride.points, Modifier.height(110.dp))

        AnimatedVisibility(visible = open) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Max", fmtKmh(ride.maxSpeedMps), "km/h", Modifier.weight(1f))
                    StatTile("Climb", "%.0f".format(ride.elevGainM), "m", Modifier.weight(1f))
                    StatTile("Energy", "≈${ride.kcalEstimate}", "kcal", Modifier.weight(1f))
                }
                GhostButton("Delete ride", onClick = onDelete, color = Palette.Danger, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
