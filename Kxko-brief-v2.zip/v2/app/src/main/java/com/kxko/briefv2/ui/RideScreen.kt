package com.kxko.briefv2.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kxko.briefv2.fmtDuration
import com.kxko.briefv2.fmtKm
import com.kxko.briefv2.fmtKmh
import com.kxko.briefv2.ride.LiveRide
import com.kxko.briefv2.ride.RideService

@Composable
fun RideScreen(live: LiveRide) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            RideService.send(ctx, RideService.ACTION_START)
        }
    }

    fun startRide() {
        val hasGps = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasGps) {
            RideService.send(ctx, RideService.ACTION_START)
        } else {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms += Manifest.permission.POST_NOTIFICATIONS
            launcher.launch(perms.toTypedArray())
        }
    }

    if (!live.active) {
        IdleRide(onStart = { startRide() })
    } else {
        ActiveRide(
            live = live,
            onPause = { RideService.send(ctx, RideService.ACTION_PAUSE) },
            onFinish = { RideService.send(ctx, RideService.ACTION_STOP) }
        )
    }
}

@Composable
private fun IdleRide(onStart: () -> Unit) {
    val t = rememberInfiniteTransition(label = "breathe")
    val breathe by t.animateFloat(
        initialValue = 1f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "breathe-scale"
    )
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Ready to ride", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "GPS tracks distance, speed and climb. Recording continues with the screen off.",
            color = Palette.TextSoft,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(40.dp))
        Box(
            Modifier
                .size(210.dp)
                .scale(breathe)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Palette.TealBright, Palette.Teal, Palette.TealDeep)))
                .clickable(onClick = onStart),
            contentAlignment = Alignment.Center
        ) {
            Text("START", color = Palette.OnTeal, fontWeight = FontWeight.Black, fontSize = 22.sp)
        }
    }
}

@Composable
private fun ActiveRide(live: LiveRide, onPause: () -> Unit, onFinish: () -> Unit) {
    val avgMps = if (live.elapsedSec > 0) live.distanceM / live.elapsedSec else 0.0
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!live.paused) PulseDot()
            Text(
                if (live.paused) "PAUSED" else "RECORDING",
                color = if (live.paused) Palette.Warning else Palette.Danger,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
        Text(fmtDuration(live.elapsedSec), style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)

        Row(verticalAlignment = Alignment.Bottom) {
            AnimatedNumber(
                value = live.speedMps,
                format = { fmtKmh(it) },
                style = MaterialTheme.typography.displayMedium,
                color = Palette.TealBright
            )
            Spacer(Modifier.width(8.dp))
            Text("km/h", color = Palette.TextSoft, fontSize = 16.sp, modifier = Modifier.padding(bottom = 8.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Distance", fmtKm(live.distanceM), "km", Modifier.weight(1f))
            StatTile("Avg", fmtKmh(avgMps), "km/h", Modifier.weight(1f))
            StatTile("Climb", "%.0f".format(live.elevGainM), "m", Modifier.weight(1f))
        }

        RouteCanvas(live.points, Modifier.height(240.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GhostButton(if (live.paused) "Resume" else "Pause", onClick = onPause, modifier = Modifier.weight(1f))
            GhostButton("Finish", onClick = onFinish, modifier = Modifier.weight(1f), color = Palette.Danger)
        }
    }
}

private fun Modifier.clip(CircleShape): Modifier = this.then(Modifier.background(Palette.Ink0, CircleShape))
