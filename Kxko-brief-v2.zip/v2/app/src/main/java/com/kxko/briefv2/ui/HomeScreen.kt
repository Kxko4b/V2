package com.kxko.briefv2.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kxko.briefv2.fmtDay
import com.kxko.briefv2.fmtDuration
import com.kxko.briefv2.fmtKm
import com.kxko.briefv2.ride.Ride
import java.util.Calendar

private const val DAY_MS = 86_400_000L
private const val WEEK_GOAL_M = 100_000.0

@Composable
fun HomeScreen(
    rides: List<Ride>,
    dueCards: Int,
    onStartRide: () -> Unit,
    onOpenStudy: () -> Unit
) {
    val now = System.currentTimeMillis()
    val week = rides.filter { now - it.startMs < 7 * DAY_MS }
    val weekM = week.sumOf { it.distanceM }
    val weekSec = week.sumOf { it.durationSec }
    val weekClimb = week.sumOf { it.elevGainM }
    val dayTotals = (6 downTo 0).map { back ->
        val start = startOfDay(now - back * DAY_MS)
        rides.filter { it.startMs >= start && it.startMs < start + DAY_MS }.sumOf { it.distanceM }.toFloat() / 1000f
    }
    val dayLabels = (6 downTo 0).map { fmtDay(now - it * DAY_MS) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(greeting(), color = Palette.TextSoft, fontSize = 15.sp)
            Text("Your week", style = MaterialTheme.typography.headlineLarge)
        }

        GlassCard(highlight = true) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                AnimatedRing(
                    fraction = (weekM / WEEK_GOAL_M).toFloat(),
                    size = 148.dp,
                    stroke = 14.dp
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedNumber(
                            value = weekM / 1000.0,
                            format = { "%.0f".format(it) },
                            style = MaterialTheme.typography.displayMedium
                        )
                        Text("of 100 km", color = Palette.TextSoft, fontSize = 12.sp)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniStat("Rides", "${week.size}")
                    MiniStat("Time", fmtDuration(weekSec))
                    MiniStat("Climb", "%.0f m".format(weekClimb))
                }
            }
        }

        GlassCard {
            SectionTitle("Last 7 days · km")
            Spacer(Modifier.height(14.dp))
            WeekBars(values = dayTotals, labels = dayLabels)
        }

        val last = rides.firstOrNull()
        GlassCard {
            SectionTitle("Last ride")
            Spacer(Modifier.height(8.dp))
            if (last == null) {
                Text("No rides yet. Your first one will show up here.", color = Palette.TextSoft)
            } else {
                Text(
                    "${fmtKm(last.distanceM)} km · ${fmtDuration(last.durationSec)}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text("Elevation +${"%.0f".format(last.elevGainM)} m", color = Palette.TextSoft, fontSize = 13.sp)
            }
        }

        GlassCard(onClick = onOpenStudy) {
            SectionTitle("Study")
            Spacer(Modifier.height(8.dp))
            Text(
                if (dueCards == 0) "All cards mastered. Nice work." else "$dueCards cards still in rotation",
                style = MaterialTheme.typography.titleMedium
            )
            Text("Tap to practise", color = Palette.TextSoft, fontSize = 13.sp)
        }

        PrimaryButton("Start a ride", onClick = onStartRide, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column {
        Text(label.uppercase(), color = Palette.TextDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        Text(value, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Good morning"
    in 12..17 -> "Good afternoon"
    else -> "Good evening"
}

private fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ms
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis
