package com.kxko.briefv2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.kxko.briefv2.study.StudyDeck
import com.kxko.briefv2.study.StudyStore
import com.kxko.briefv2.ride.RideStore
import com.kxko.briefv2.ride.RideTracker
import com.kxko.briefv2.ui.BriefTheme
import com.kxko.briefv2.ui.HistoryScreen
import com.kxko.briefv2.ui.HomeScreen
import com.kxko.briefv2.ui.Palette
import com.kxko.briefv2.ui.RideScreen
import com.kxko.briefv2.ui.StudyScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Palette.Ink1.toArgb())
        )
        setContent {
            BriefTheme { BriefApp() }
        }
    }
}

enum class Tab(val label: String, val glyph: String) {
    Home("Home", "◉"),
    Ride("Ride", "↗"),
    Study("Study", "✎"),
    History("History", "≡")
}

@Composable
fun BriefApp() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var rides by remember { mutableStateOf(RideStore.load(ctx)) }
    var boxes by remember { mutableStateOf(StudyStore.load(ctx)) }
    val live by RideTracker.state.collectAsState()

    // Reload saved rides whenever a ride starts or ends.
    LaunchedEffect(live.active) { rides = RideStore.load(ctx) }

    val cards = StudyDeck.cards
    val dueCards = cards.count { StudyStore.box(boxes, it.id) < StudyStore.MAX_BOX }

    Scaffold(
        containerColor = Palette.Ink0,
        bottomBar = { BottomNav(selected = tab, onSelect = { tab = it }) }
    ) { padding ->
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.fillMaxSize().padding(padding),
            transitionSpec = {
                (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 12 }) togetherWith fadeOut(tween(140))
            },
            label = "tab-switch"
        ) { current ->
            when (current) {
                Tab.Home -> HomeScreen(
                    rides = rides,
                    dueCards = dueCards,
                    onStartRide = { tab = Tab.Ride },
                    onOpenStudy = { tab = Tab.Study }
                )
                Tab.Ride -> RideScreen(live = live)
                Tab.Study -> StudyScreen(
                    cards = cards,
                    boxes = boxes,
                    onGrade = { id, gotIt ->
                        StudyStore.update(ctx, id, gotIt)
                        boxes = StudyStore.load(ctx)
                    }
                )
                Tab.History -> HistoryScreen(
                    rides = rides,
                    onDelete = { id ->
                        RideStore.delete(ctx, id)
                        rides = RideStore.load(ctx)
                    }
                )
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Palette.Ink1)
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Tab.values().forEach { t ->
            val active = t == selected
            val pill by animateColorAsState(if (active) Palette.TealSoft else Color.Transparent, tween(250), label = "pill")
            val fg by animateColorAsState(if (active) Palette.TealBright else Palette.TextDim, tween(250), label = "fg")
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable(role = Role.Tab) { onSelect(t) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(pill)
                        .padding(horizontal = 18.dp, vertical = 4.dp)
                ) {
                    Text(t.glyph, color = fg, fontSize = 18.sp)
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    t.label,
                    color = fg,
                    fontSize = 11.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

