package com.kxko.briefv2.study

import android.content.Context
import org.json.JSONObject

data class Card(val id: String, val front: String, val back: String)

/** Built-in sample deck. Editable in code; sync with a backend can be added later. */
object StudyDeck {
    val cards: List<Card> = listOf(
        Card("tyre", "Rough pressure range for 25 mm road tyres?", "About 80–100 psi (5.5–7 bar), depending on rider weight and surface."),
        Card("cadence", "Cadence most riders find efficient?", "Roughly 80–100 rpm."),
        Card("abc", "What does the ABC bike check cover?", "Air (tyre pressure), Brakes, Chain and cranks."),
        Card("helmet", "How should a helmet fit?", "Snug and level, sitting about two finger-widths above the eyebrows."),
        Card("zone2", "What is Zone 2 training?", "Easy, conversational effort, roughly 60–70 % of max heart rate."),
        Card("fluids", "Typical fluid intake on a long ride?", "Roughly 500–1000 ml per hour, more in heat or hard effort."),
        Card("carbs", "Carbs per hour on rides over 90 minutes?", "Often around 30–60 g per hour."),
        Card("bonk", "What is 'bonking'?", "Sudden exhaustion from depleted glycogen stores."),
        Card("left", "Hand signal for turning left?", "Left arm straight out to the side."),
        Card("stop", "Hand signal for stopping?", "Left arm pointing down, palm facing back.")
    )
}

/**
 * Leitner boxes 1..5. "Got it" moves a card up a box, "Again" sends it back to box 1.
 * The next card shown is always the one in the lowest box.
 */
object StudyStore {
    private const val PREFS = "study_v2"
    private const val KEY = "boxes"
    const val MAX_BOX = 5

    fun load(ctx: Context): Map<String, Int> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun update(ctx: Context, id: String, gotIt: Boolean) {
        val boxes = load(ctx).toMutableMap()
        val current = boxes[id] ?: 1
        boxes[id] = if (gotIt) (current + 1).coerceAtMost(MAX_BOX) else 1
        val o = JSONObject()
        boxes.forEach { (k, v) -> o.put(k, v) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun box(boxes: Map<String, Int>, id: String): Int = boxes[id] ?: 1

    fun nextCard(cards: List<Card>, boxes: Map<String, Int>): Card? =
        cards.filter { box(boxes, it.id) < MAX_BOX }.minByOrNull { box(boxes, it.id) }

    fun masteredCount(cards: List<Card>, boxes: Map<String, Int>): Int =
        cards.count { box(boxes, it.id) >= MAX_BOX }
}
