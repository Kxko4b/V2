package com.kxko.briefv2

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtDuration(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

fun fmtKm(meters: Double): String = "%.1f".format(meters / 1000.0)

fun fmtKmh(mps: Double): String = "%.1f".format(mps * 3.6)

fun fmtDate(ms: Long): String = SimpleDateFormat("EEE d MMM · HH:mm", Locale.getDefault()).format(Date(ms))

fun fmtDay(ms: Long): String = SimpleDateFormat("EEE", Locale.getDefault()).format(Date(ms))
